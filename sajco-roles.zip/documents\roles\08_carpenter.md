# Carpenter (Mold Maker)

## Department
Production

## Role Overview
The Carpenter (also called Mold Maker or Formwork Carpenter) builds, 
sets up, and maintains the molds used to cast precast concrete elements. 
They work with timber, steel, and composite molds to create precise 
shapes that match the shop drawings. Mold accuracy directly affects the 
final product quality.

## Key Responsibilities
- Reading shop drawings to understand mold requirements
- Building new molds from timber, plywood, or steel
- Setting up molds on casting beds or tables
- Applying mold release agents (oil)
- Installing block-outs, openings, and embedments
- Sealing mold joints to prevent concrete leakage
- Stripping (dismantling) molds after curing
- Repairing and maintaining molds for reuse
- Ensuring dimensional accuracy of molds
- Coordinating with Steel Fixer and QC for setup approval

## Required Skills
- Reading technical and shop drawings
- Carpentry and mold-making craftsmanship
- Use of power tools (saws, drills, grinders)
- Welding (for steel molds)
- Measuring and leveling
- Geometry and spatial reasoning
- Attention to detail
- Safety awareness

## Tools and Equipment Used
- Power saws (circular, jig, table)
- Drills and impact drivers
- Grinders and sanders
- Welding machine (for steel molds)
- Levels (spirit, laser)
- Measuring tapes, squares, plumb bobs
- Mold release oil sprayers
- PPE (gloves, eye protection, ear protection, dust mask)

## Key Performance Indicators (KPIs)
- Molds set up per day
- Dimensional accuracy (target: within plus or minus 2mm)
- Mold reuse cycles before repair
- Concrete leakage incidents (target: zero)
- Pre-pour inspection pass rate
- Safety incidents (target: zero)

## Best Practices
- Always verify mold dimensions against the drawing
- Apply mold release oil evenly — too much causes surface defects
- Seal all joints carefully to prevent concrete loss
- Mark mold orientation clearly (top, bottom, sides)
- Inspect molds for damage before reuse
- Store molds properly to prevent warping
- Coordinate strip timing with curing requirements

## Common Challenges
- Mold warping after multiple uses
- Tight tolerances on complex shapes
- Coordinating with steel fixers on cage placement
- Block-out positioning accuracy
- Stripping without damaging the precast element

## Related Roles
- Reports to: Foreman
- Coordinates with: Steel Fixer, Production Engineer, QC Technician
- Works alongside: Concrete pouring team