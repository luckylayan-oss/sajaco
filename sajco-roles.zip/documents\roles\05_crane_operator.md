# Crane Operator

## Department
Production / Logistics

## Role Overview
The Crane Operator is responsible for lifting, moving, and placing heavy 
precast concrete elements within the factory and onto trucks for dispatch. 
This is a safety-critical role — a single mistake can damage products, 
equipment, or cause serious injury. Crane Operators work closely with 
Riggers, Foremen, and Dispatch staff.

## Key Responsibilities
- Operating overhead, gantry, or mobile cranes
- Lifting precast elements from molds or casting beds
- Moving elements to curing yards or storage areas
- Loading finished products onto trucks for delivery
- Inspecting crane and rigging equipment daily
- Following lifting plans and load charts
- Communicating with Riggers via hand signals or radio
- Reporting any equipment defects immediately
- Maintaining lift logs
- Following all safety procedures strictly

## Required Skills
- Certified Crane Operator license
- Knowledge of load charts and lifting capacities
- Understanding of center of gravity and balance
- Hand signal and radio communication
- Spatial awareness
- Calm under pressure
- Mechanical knowledge of cranes
- Strict safety discipline

## Tools and Equipment Used
- Overhead cranes, gantry cranes, mobile cranes
- Lifting slings, chains, and shackles
- Spreader beams
- Lifting clutches and anchors (cast into precast elements)
- Two-way radios
- PPE (helmet, gloves, harness, boots)
- Daily inspection checklists

## Key Performance Indicators (KPIs)
- Lifts completed per shift
- Damage incidents (target: zero)
- Safety incidents (target: zero)
- Crane uptime (target: 95% or higher)
- On-time loading of trucks
- Compliance with lifting plan procedures

## Best Practices
- Always inspect rigging before every lift
- Never lift over people — clear the area first
- Confirm the lift plan with the Foreman before starting
- Use a tagline to control swinging loads
- Communicate constantly with the Rigger
- Stop the lift immediately if anything feels wrong
- Never exceed rated load capacity
- Lower loads slowly and gently

## Common Challenges
- Wind affecting outdoor lifts
- Awkward shapes and uneven loads
- Coordinating multiple lifts in the same area
- Communication errors with riggers
- Tight spaces during truck loading

## Related Roles
- Reports to: Foreman / Production Engineer
- Works closely with: Riggers, Steel Fixers, Dispatch Officer
- Coordinates with: Production Engineer for daily lift schedule