# Extruder Operator

## Department
Production

## Role Overview
The Extruder Operator runs the extrusion machine that produces hollow-core 
slabs and other extruded precast elements. They control the machine's speed, 
concrete feed, and quality, ensuring each element meets dimensional and 
structural requirements.

## Key Responsibilities
- Operating the extrusion machine safely and efficiently
- Setting up the casting bed before extrusion (cleaning, oiling, prestressing)
- Loading concrete from the batching plant into the extruder
- Monitoring the extrusion process for consistency
- Ensuring proper concrete compaction
- Coordinating with Steel Fixer for prestressing strands
- Performing routine machine maintenance
- Recording production data (length, time, mix used)
- Cleaning the machine and bed after each run
- Working with QC for in-process inspections

## Required Skills
- Operating heavy precast machinery
- Understanding of prestressed concrete
- Reading shop drawings
- Mechanical troubleshooting
- Attention to detail
- Physical fitness and stamina
- Safety awareness
- Teamwork

## Tools and Equipment Used
- Extruder machine
- Casting beds (long-line)
- Prestressing strands and jacks
- Bed cleaning tools (scrapers, brushes, vacuum)
- Mold release oil sprayers
- Measuring tapes, calipers
- Personal Protective Equipment (PPE)

## Key Performance Indicators (KPIs)
- Linear meters extruded per shift
- Defect rate (target: less than 2%)
- Machine uptime (target: 90% or higher)
- Bed turnaround time
- Concrete wastage rate
- Safety incidents (target: zero)

## Best Practices
- Always inspect the bed before extrusion (clean, oiled, level)
- Verify prestressing values match the shop drawing
- Maintain consistent feed rate during extrusion
- Watch for surface defects in real-time and adjust
- Clean the machine thoroughly after every run
- Never bypass safety interlocks
- Coordinate cutting marks accurately for finished elements

## Common Challenges
- Concrete consistency variations from batching
- Strand slippage during prestressing
- Machine wear affecting product quality
- Bed cleaning between runs slowing throughput
- Weather affecting curing on the bed

## Related Roles
- Reports to: Foreman / Production Engineer
- Coordinates with: Batching Operator, Steel Fixer, QC Technician
- Works alongside: Crane Operator (for lifting finished elements)