# QC Technician

## Department
Quality

## Role Overview
The QC Technician (Quality Control Technician) performs hands-on inspections 
and tests at every stage of precast production. They are the eyes and hands 
of the QA/QC Manager on the factory floor, ensuring that what gets produced 
matches what was designed.

## Key Responsibilities
- Performing pre-pour inspections (rebar, embeds, mold dimensions)
- Performing post-pour inspections (surface finish, dimensions)
- Conducting slump tests on every concrete batch
- Casting concrete cubes for compressive strength testing
- Inspecting cured elements for cracks and defects
- Verifying dimensions against shop drawings
- Issuing Non-Conformance Reports (NCRs) when needed
- Approving elements for de-molding and dispatch
- Maintaining inspection records and logs
- Coordinating with Foreman to release production holds

## Required Skills
- Diploma or degree in Civil/Construction
- Reading shop drawings and BBS
- Knowledge of concrete testing standards
- Familiarity with inspection checklists
- Attention to detail
- Independence and integrity
- Good communication
- Basic computer skills for reports

## Tools and Equipment Used
- Slump cone, tamping rod
- Concrete cube molds (150mm x 150mm x 150mm)
- Calipers, measuring tapes, levels
- Crack gauges
- Cover meters (rebar scanner)
- Schmidt hammer (rebound test)
- Inspection checklists (paper or tablet)
- Camera for documentation
- PPE

## Key Performance Indicators (KPIs)
- Inspections completed per shift
- Defects detected before dispatch (target: 100%)
- Inspection accuracy (target: 100%)
- Report submission timeliness
- NCR documentation completeness
- Concrete cube test scheduling compliance

## Best Practices
- Inspect with the checklist — don't rely on memory
- Take photos of every inspection (good and bad)
- Stop work immediately if you see a safety or quality issue
- Be firm but respectful when issuing NCRs
- Cast cubes at the EXACT mix design strength being poured
- Keep cube curing tank water temperature controlled
- Label every cube with date, mix, and element ID
- Communicate findings to Foreman immediately

## Common Challenges
- Pressure from Foreman to skip inspections for speed
- Detecting hidden defects (e.g., honeycombing)
- Coordinating inspection timing with production flow
- Heat exposure during outdoor inspections
- Managing inspection backlog during peak production

## Related Roles
- Reports to: QA/QC Manager
- Coordinates with: Foreman, Production Engineer, Steel Fixer, Carpenter
- Works alongside: Lab Technician (for cube testing)