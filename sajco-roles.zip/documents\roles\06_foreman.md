# Foreman

## Department
Production

## Role Overview
The Foreman is the on-the-ground leader of the production team. They 
supervise the daily activities of Steel Fixers, Carpenters, Extruder 
Operators, and other production workers. The Foreman bridges the gap 
between the Production Engineer's plan and the workers executing it.

## Key Responsibilities
- Supervising production teams on the factory floor
- Assigning daily tasks to workers
- Ensuring shop drawings and BBS are followed correctly
- Conducting daily toolbox talks (safety briefings)
- Monitoring work progress and quality
- Coordinating with Production Engineer on schedules
- Coordinating with QC for inspection holds and approvals
- Managing manpower attendance and shifts
- Solving on-the-spot production problems
- Reporting daily production output
- Ensuring workplace cleanliness and safety

## Required Skills
- Strong leadership and people management
- Deep practical knowledge of precast production
- Reading shop drawings and BBS
- Conflict resolution
- Communication in multiple languages (helpful in diverse workforces)
- Problem-solving
- Time management
- Safety leadership

## Tools and Equipment Used
- Shop drawings and BBS
- Daily production trackers
- Two-way radios
- Measuring tools (tape, calipers)
- Whistle for crew coordination
- PPE
- Attendance sheets

## Key Performance Indicators (KPIs)
- Daily production target achievement (target: 95% or higher)
- Worker attendance rate
- Safety incidents (target: zero)
- Quality rejection rate (target: less than 2%)
- Toolbox talks completed (target: 100%)
- Housekeeping audit score

## Best Practices
- Conduct toolbox talks every morning before work starts
- Walk the floor constantly — don't sit in the office
- Know every worker by name
- Address quality issues immediately, don't pass them on
- Document all incidents (safety, quality, attendance)
- Praise good work in public, correct mistakes in private
- Coordinate with QC early to avoid rework
- End-of-shift handover with night shift Foreman

## Common Challenges
- Worker absenteeism affecting schedules
- Language barriers in multicultural teams
- Balancing speed with quality
- Tool and material availability
- Resolving conflicts between workers

## Related Roles
- Reports to: Production Engineer / Production Manager
- Supervises: Steel Fixers, Carpenters, Extruder Operators, helpers
- Coordinates with: QC Technician, Crane Operator, Batching Operator