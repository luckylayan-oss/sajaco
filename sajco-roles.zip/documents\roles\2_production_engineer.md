# Production Engineer

## Department
Production

## Role Overview
The Production Engineer is responsible for planning, optimizing, and 
supervising the precast concrete production process. They translate 
approved Job Orders (JO) into production schedules, ensure efficient 
use of resources, and coordinate with the Foreman, QC, and Supply Chain 
to deliver products on time and to specification.

## Key Responsibilities
- Translating Job Orders into production schedules
- Planning daily and weekly production activities
- Coordinating with Foreman to assign tasks
- Monitoring production progress and bottlenecks
- Ensuring raw materials are available before production
- Optimizing molding, casting, and curing processes
- Coordinating with QC for in-process inspections
- Reporting production status to PMO and Factory Manager
- Implementing process improvements
- Ensuring compliance with technical drawings and specifications

## Required Skills
- Civil or Mechanical Engineering background
- Strong knowledge of precast concrete production
- Production planning and scheduling
- Reading technical drawings (shop drawings, BBS)
- Problem-solving and root cause analysis
- ERP/MRP systems experience
- Lean manufacturing principles
- Time management
- Team coordination

## Tools and Equipment Used
- Production planning software (ERP/MRP)
- Shop drawings and Bar Bending Schedules (BBS)
- Mix design documents
- Production tracking sheets
- Calipers, measuring tapes for verification
- Factory layout maps

## Key Performance Indicators (KPIs)
- Production output (units per day/week)
- Schedule adherence (target: 95% or higher)
- Material wastage rate (target: less than 3%)
- Cycle time per element
- Rework rate (target: less than 2%)
- Mold utilization rate
- Downtime hours

## Best Practices
- Start each day with a production huddle with Foreman
- Verify raw material availability the day before
- Always cross-check shop drawings before casting
- Maintain mold rotation schedule
- Document any deviations and their reasons
- Coordinate early with QC for inspection slots

## Common Challenges
- Mold availability and rotation conflicts
- Raw material shortages
- Last-minute design changes from clients
- Coordinating with multiple trades (steel fixers, carpenters, batching)
- Weather affecting curing times

## Related Roles
- Reports to: Production Manager / Factory Manager
- Coordinates with: Foreman, QC Technician, Batching Operator, PMO
- Supervises: Production line workers