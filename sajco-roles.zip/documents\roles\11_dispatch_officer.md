# Dispatch Officer

## Department
Logistics / Supply Chain

## Role Overview
The Dispatch Officer is responsible for planning and managing the delivery 
of finished precast elements from the factory to the construction site. 
They coordinate trucks, loading sequences, and documentation, ensuring 
products arrive on time, in the right order, and in good condition.

## Key Responsibilities
- Planning daily and weekly dispatch schedules
- Coordinating with site teams for delivery requirements
- Booking trucks and trailers (flatbed, low-bed, extendable)
- Planning loading sequences based on installation order
- Coordinating with Crane Operator for truck loading
- Preparing dispatch documents (delivery notes, invoices, manifests)
- Inspecting elements before loading (final check)
- Ensuring proper lashing and securing of loads
- Tracking trucks until delivery confirmation
- Handling damages-in-transit claims
- Coordinating with QC for dispatch approval

## Required Skills
- Logistics and supply chain knowledge
- Understanding of precast element handling
- Truck and load planning
- Knowledge of road regulations for oversized loads
- Documentation and record-keeping
- Communication with drivers and site teams
- Problem-solving (route changes, delays)
- Basic computer skills (Excel, ERP)

## Tools and Equipment Used
- Dispatch scheduling software (ERP)
- Delivery note printers
- Two-way radios
- Loading inspection checklists
- Lashing belts, chains, wooden dunnage
- Camera for documenting loading
- GPS tracking systems
- PPE

## Key Performance Indicators (KPIs)
- On-time delivery rate (target: 95% or higher)
- Damages in transit (target: less than 1%)
- Truck utilization rate (target: 90% or higher)
- Documentation accuracy (target: 100%)
- Dispatch cycle time
- Driver safety incidents (target: zero)

## Best Practices
- Plan dispatches at least 24 hours in advance
- Confirm site readiness before dispatching
- Load elements in REVERSE installation order (first installed = last loaded)
- Use proper dunnage between stacked elements
- Photograph every loaded truck before departure
- Brief drivers on route and delivery procedures
- Never dispatch a damaged or non-conforming element
- Track every truck with GPS and confirm delivery

## Common Challenges
- Site delays preventing scheduled deliveries
- Traffic and route restrictions for oversized loads
- Last-minute changes in installation sequence
- Truck breakdowns
- Coordinating multiple sites simultaneously
- Weather affecting transport safety

## Related Roles
- Reports to: Supply Chain Manager / Factory Manager
- Coordinates with: Crane Operator, QC Technician, Site Engineer, Drivers
- Works alongside: Production Engineer (for dispatch readiness)