# Steel Fixer

## Department
Production

## Role Overview
The Steel Fixer (also called Rebar Worker or Reinforcement Specialist) 
fabricates and installs steel reinforcement cages inside precast molds 
according to the Bar Bending Schedule (BBS) and shop drawings. The 
strength of the precast element depends on the Steel Fixer's accuracy.

## Key Responsibilities
- Reading and interpreting Bar Bending Schedules (BBS)
- Cutting and bending steel reinforcement bars to required shapes
- Tying rebar cages with binding wire
- Installing rebar cages into molds correctly
- Ensuring proper concrete cover (using spacers)
- Installing prestressing strands when required
- Embedding lifting anchors and connection plates
- Coordinating with QC for pre-pour inspection
- Maintaining tools and work area
- Following safety procedures

## Required Skills
- Reading BBS and shop drawings
- Understanding of structural reinforcement principles
- Manual dexterity and physical strength
- Use of cutting and bending machines
- Knowledge of bar diameters and grades
- Attention to detail
- Teamwork
- Safety awareness

## Tools and Equipment Used
- Rebar cutting machine
- Rebar bending machine
- Binding wire and pliers (rebar tying tools)
- Measuring tapes and chalk lines
- Concrete cover spacers (plastic, fiber, or steel)
- Lifting anchors and embeds
- PPE (gloves, safety glasses, helmet, steel-toe boots)

## Key Performance Indicators (KPIs)
- Cages produced per day
- Rework rate (target: less than 2%)
- BBS compliance accuracy (target: 100%)
- Material wastage (target: less than 3%)
- Pre-pour inspection pass rate (target: 95% or higher)
- Safety incidents (target: zero)

## Best Practices
- Always cross-check BBS before cutting
- Measure twice, cut once
- Use proper concrete cover spacers (don't skip them)
- Tie cages tightly so they don't shift during pouring
- Embed lifting anchors at exact locations from the drawing
- Mark and label cages for traceability
- Clean up offcuts at the end of every shift

## Common Challenges
- Misreading BBS leading to wrong shapes
- Rebar shortages or wrong delivery
- Tight congested cages making tying difficult
- Heat fatigue in summer
- Coordinating embeds with multiple trades

## Related Roles
- Reports to: Foreman
- Coordinates with: Carpenter (for mold setup), Extruder Operator, QC Technician
- Works alongside: Concrete pouring team