# QA/QC Manager

## Department
Quality

## Role Overview
The QA/QC Manager leads the Quality Assurance and Quality Control function 
of the precast factory. They establish quality standards, supervise QC 
Technicians, manage inspections, handle non-conformances, and ensure all 
products meet client specifications and industry standards (ACI, BS, EN).

## Key Responsibilities
- Developing and maintaining the Quality Management System (QMS)
- Setting quality standards and inspection procedures
- Supervising QC Technicians and inspectors
- Reviewing concrete mix designs
- Managing material testing (cement, aggregate, steel, concrete)
- Conducting internal quality audits
- Handling Non-Conformance Reports (NCRs)
- Approving products for dispatch
- Coordinating with client quality representatives
- Maintaining quality records and certificates
- Training staff on quality procedures

## Required Skills
- Civil Engineering degree (concrete specialization preferred)
- Knowledge of international standards (ACI, BS EN, ASTM)
- Quality Management Systems (ISO 9001)
- Concrete technology expertise
- Material testing procedures
- Statistical quality control
- Leadership and team management
- Report writing
- Client communication

## Tools and Equipment Used
- Quality Management System (QMS) software
- Laboratory testing equipment
- Compression testing machines (concrete cubes)
- Slump cones, air content meters
- Calipers, measuring tools
- Non-destructive testing (NDT) equipment
- Inspection checklists
- NCR forms and tracking systems

## Key Performance Indicators (KPIs)
- Quality rejection rate (target: less than 2%)
- NCR closure time (target: less than 7 days)
- Concrete cube test pass rate (target: 98% or higher)
- Audit findings closure rate
- Client quality complaints (target: zero)
- Inspection completion rate (target: 100%)
- Material test compliance

## Best Practices
- Inspect at every stage: pre-pour, post-pour, post-cure, pre-dispatch
- Never let a non-conforming product leave the factory
- Document everything — photos, measurements, signatures
- Train QC Technicians continuously
- Build a strong relationship with the Production team
- Maintain calibration records for all testing equipment
- Conduct monthly quality review meetings
- Stay updated with code revisions

## Common Challenges
- Pressure from Production to release borderline products
- Aggregate or cement quality variations
- Disagreements with clients on acceptance criteria
- Managing multiple inspections simultaneously
- Keeping records audit-ready at all times

## Related Roles
- Reports to: Factory Manager
- Supervises: QC Technicians, Lab Technicians
- Coordinates with: Production Engineer, Foreman, Dispatch Officer, Client QC