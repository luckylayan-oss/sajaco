# Factory Manager

## Department
Management

## Role Overview
The Factory Manager is the highest authority in the precast concrete factory. 
This role oversees all departments (Sales, Estimation, PMO, Technical, QC, 
Production, Supply Chain, Installation) and ensures the factory operates 
efficiently, safely, and profitably. The Factory Manager is the final 
approver for Quotations (QT), Contracts, and Job Orders (JO).

## Key Responsibilities
- Overall factory management and leadership
- Cross-departmental coordination
- Monitoring factory budget and financial performance
- Monitoring factory performance and KPIs
- Approving Quotations (QT) submitted by Sales
- Approving Contracts before Job Order creation
- Approving Job Orders before production starts
- Strategic decision-making
- Ensuring compliance with safety and quality standards
- Client relationship management at executive level

## Required Skills
- Leadership and team management
- Strategic planning
- Financial literacy and budget management
- Knowledge of precast concrete production processes
- Negotiation skills
- Risk management
- Decision-making under pressure
- Communication (verbal and written)
- Conflict resolution

## Tools and Equipment Used
- Daily production reports (paper and digital)
- Clipboards for floor inspections
- Two-way radios for instant communication
- Factory dashboards and KPI boards
- Meeting rooms for coordination

## Key Performance Indicators (KPIs)
- On-time project delivery rate (target: 95% or higher)
- Budget variance (target: within plus or minus 5%)
- Quality rejection rate (target: less than 2%)
- Safety incident rate (target: zero Lost Time Incidents)
- Client satisfaction score
- Employee retention rate
- Production efficiency rate

## Approval Authorities
1. Quotation (QT) Approval — reviews pricing and feasibility
2. Contract Approval — reviews terms before signing
3. Job Order (JO) Approval — authorizes production to begin

## Best Practices
- Conduct daily walk-throughs of the factory floor
- Hold weekly cross-departmental meetings
- Review KPI dashboards every morning
- Maintain open-door policy for all employees
- Prioritize safety over schedule, always
- Document all major decisions with reasoning

## Common Challenges
- Balancing schedule pressure with quality requirements
- Managing conflicts between departments
- Cash flow management during long projects
- Maintaining morale during high-pressure periods
- Adapting to client scope changes mid-project

## Related Roles
- Reports to: Company executives and Board
- Direct reports: All department heads (PMO, Sales, Production, QC, and others)
- Close coordination: PMO Manager, QA/QC Manager